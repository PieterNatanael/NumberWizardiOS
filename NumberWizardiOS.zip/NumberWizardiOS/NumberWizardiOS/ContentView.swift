//
//  ContentView.swift
//  NumberWizardiOS
//
//  Created by Pieter Yoshua Natanael on 22/09/23.
//

import SwiftUI


struct NumberWizardApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

struct ContentView: View {
    @State private var targetNumber = Int.random(in: 1...100)
    @State private var userGuess = ""
    @State private var message = ""
    @State private var showAlert = false

    var body: some View {
        VStack {
            Text("Welcome to NumberWizard")
                .font(.headline)
                .padding()

            Text("Guess a number between 1 and 100:")
                .font(.subheadline)
                .padding()

            TextField("Enter your guess", text: $userGuess)
                .padding()

            Button("Submit Guess") {
                checkGuess()
            }
            .padding()

            Text(message)
                .font(.subheadline)
                .foregroundColor(messageColor())
                .padding()

        }
        .alert(isPresented: $showAlert) {
            Alert(
                title: Text("Congratulations!"),
                message: Text("You guessed the number \(targetNumber)!"),
                dismissButton: .default(Text("Play Again")) {
                    resetGame()
                }
            )
        }
    }

    func checkGuess() {
        guard let guess = Int(userGuess) else {
            message = "Please enter a valid number."
            return
        }

        if guess < 1 || guess > 100 {
            message = "Please enter a number between 1 and 100."
        } else if guess == targetNumber {
            message = "Congratulations! You guessed the number \(targetNumber)!"
            showAlert = true
        } else if guess < targetNumber {
            message = "Try a higher number."
        } else {
            message = "Try a lower number."
        }
    }

    func resetGame() {
        targetNumber = Int.random(in: 1...100)
        userGuess = ""
        message = ""
    }

    func messageColor() -> Color {
        if message.contains("Congratulations") {
            return .green
        } else {
            return .red
        }
    }
}



/*

import SwiftUI


struct NumberWizardApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

struct ContentView: View {
    @State private var targetNumber = Int.random(in: 1...100)
    @State private var guess = ""
    @State private var isGameOver = false
    @State private var feedback = ""
    @State private var attempts = 0
    
    var body: some View {
        VStack {
            Text("Number Wizard")
                .font(.largeTitle)
                .padding()
            
            Text("I'm thinking of a number between 1 and 100.")
            
            TextField("Enter your guess", text: $guess)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .keyboardType(.numberPad)
                .padding()
                .onChange(of: guess) { newValue in
                    // Ensure that guess is updated when the user enters text
                    guess = newValue
                }
            
            Button("Submit Guess") {
                checkGuess()
            }
            .padding()
            
            if isGameOver {
                Text(feedback)
                    .font(.headline)
                    .padding()
                
                Button("Play Again") {
                    restartGame()
                }
                .padding()
            }
        }
    }
    
    func checkGuess() {
        guard let guessedNumber = Int(guess) else {
            feedback = "Please enter a valid number."
            return
        }
        
        attempts += 1
        
        if guessedNumber == targetNumber {
            feedback = "Congratulations! You guessed it in \(attempts) attempts."
            isGameOver = true
        } else if guessedNumber < targetNumber {
            feedback = "Try higher."
        } else {
            feedback = "Try lower."
        }
    }
    
    func restartGame() {
        targetNumber = Int.random(in: 1...100)
        guess = ""
        isGameOver = false
        feedback = ""
        attempts = 0
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}




import SwiftUI


struct NumberWizardApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

struct ContentView: View {
    @State private var targetNumber = Int.random(in: 1...100)
    @State private var guess = ""
    @State private var isGameOver = false
    @State private var feedback = ""
    @State private var attempts = 0
    
    var body: some View {
        VStack {
            Text("Number Wizard")
                .font(.largeTitle)
                .padding()
            
            Text("Guess a number between 1 and 100.")
            
            TextField("Enter your guess", text: $guess)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .keyboardType(.numberPad)
                .padding()
            
            Button("Submit Guess") {
                checkGuess()
            }
            .padding()
            
            if isGameOver {
                Text(feedback)
                    .font(.headline)
                    .padding()
                
                Button("Play Again") {
                    restartGame()
                }
                .padding()
            }
        }
    }
    
    func checkGuess() {
        guard let guessedNumber = Int(guess) else {
            feedback = "Please enter a valid number."
            return
        }
        
        attempts += 1
        
        if guessedNumber == targetNumber {
            feedback = "Congratulations! You guessed it in \(attempts) attempts."
            isGameOver = true
        } else if guessedNumber < targetNumber {
            feedback = "Try higher."
        } else {
            feedback = "Try lower."
        }
    }
    
    func restartGame() {
        targetNumber = Int.random(in: 1...100)
        guess = ""
        isGameOver = false
        feedback = ""
        attempts = 0
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}



import SwiftUI


struct NumberWizardApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

struct ContentView: View {
    @State private var targetNumber = Int.random(in: 1...100)
    @State private var guess = ""
    @State private var isGameOver = false
    @State private var feedback = ""
    @State private var attempts = 0
    
    var body: some View {
        VStack {
            Text("Number Wizard")
                .font(.largeTitle)
                .padding()
            
            Text("I'm thinking of a number between 1 and 100.")
            
            TextField("Enter your guess", text: $guess)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .keyboardType(.numberPad)
                .padding()
            
            Button("Submit Guess") {
                checkGuess()
            }
            .padding()
            
            if isGameOver {
                Text(feedback)
                    .font(.headline)
                    .padding()
                
                Button("Play Again") {
                    restartGame()
                }
                .padding()
            }
        }
    }
    
    func checkGuess() {
        guard let guessedNumber = Int(guess) else {
            feedback = "Please enter a valid number."
            return
        }
        
        attempts += 1
        
        if guessedNumber == targetNumber {
            feedback = "Congratulations! You guessed it in \(attempts) attempts."
            isGameOver = true
        } else if guessedNumber < targetNumber {
            feedback = "Try higher."
        } else {
            feedback = "Try lower."
        }
    }
    
    func restartGame() {
        targetNumber = Int.random(in: 1...100)
        guess = ""
        isGameOver = false
        feedback = ""
        attempts = 0
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


import SwiftUI


struct NumberWizardApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

struct ContentView: View {
    @State private var targetNumber = Int.random(in: 1...100)
    @State private var guess = ""
    @State private var isGameOver = false
    @State private var feedback = ""
    @State private var attempts = 0
    
    var body: some View {
        VStack {
            Text("Number Wizard")
                .font(.largeTitle)
                .padding()
            
            Text("I'm thinking of a number between 1 and 100.")
            
            TextField("Enter your guess", text: $guess)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .keyboardType(.numberPad)
                .padding()
            
            Button("Submit Guess") {
                checkGuess()
            }
            .padding()
            
            if isGameOver {
                Text(feedback)
                    .font(.headline)
                    .padding()
                
                Button("Play Again") {
                    restartGame()
                }
                .padding()
            }
        }
    }
    
    func checkGuess() {
        guard let guessedNumber = Int(guess) else {
            feedback = "Please enter a valid number."
            return
        }
        
        attempts += 1
        
        if guessedNumber == targetNumber {
            feedback = "Congratulations! You guessed it in \(attempts) attempts."
            isGameOver = true
        } else if guessedNumber < targetNumber {
            feedback = "Try higher."
        } else {
            feedback = "Try lower."
        }
    }
    
    func restartGame() {
        targetNumber = Int.random(in: 1...100)
        guess = ""
        isGameOver = false
        feedback = ""
        attempts = 0
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundColor(.accentColor)
            Text("Hello, world!")
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
*/
