//
//  ContentView.swift
//  NumberWizardiOS
//
//  Created by Pieter Yoshua Natanael on 22/09/23.
//

import SwiftUI


struct NumberWizardApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

struct ContentView: View {
    @State private var targetNumber = Int.random(in: 1...100)
    @State private var guess = ""
    @State private var isGameOver = false
    
    var body: some View {
        VStack {
            Text("Number Wizard")
                .font(.largeTitle)
                .padding()
            
            Text("Guess a number between 1 and 100.")
            
            TextField("Enter your guess", text: $guess)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .keyboardType(.numberPad)
                .padding()
            
            Button("Submit Guess") {
                isGameOver = true // Temporary logic for testing
            }
            .padding()
            
            if isGameOver {
                Text("Game Over")
                    .font(.headline)
                    .padding()
                
                Button("Play Again") {
                    restartGame()
                }
                .padding()
            }
        }
    }
    
    func restartGame() {
        targetNumber = Int.random(in: 1...100)
        guess = ""
        isGameOver = false
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}



/*

import SwiftUI


struct NumberWizardApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

struct ContentView: View {
    @State private var targetNumber = Int.random(in: 1...100)
    @State private var guess = ""
    @State private var isGameOver = false
    @State private var feedback = ""
    @State private var attempts = 0
    
    var body: some View {
        VStack {
            Text("Number Wizard")
                .font(.largeTitle)
                .padding()
            
            Text("I'm thinking of a number between 1 and 100.")
            
            TextField("Enter your guess", text: $guess)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .keyboardType(.numberPad)
                .padding()
                .onChange(of: guess) { newValue in
                    // Ensure that guess is updated when the user enters text
                    guess = newValue
                }
            
            Button("Submit Guess") {
                checkGuess()
            }
            .padding()
            
            if isGameOver {
                Text(feedback)
                    .font(.headline)
                    .padding()
                
                Button("Play Again") {
                    restartGame()
                }
                .padding()
            }
        }
    }
    
    func checkGuess() {
        guard let guessedNumber = Int(guess) else {
            feedback = "Please enter a valid number."
            return
        }
        
        attempts += 1
        
        if guessedNumber == targetNumber {
            feedback = "Congratulations! You guessed it in \(attempts) attempts."
            isGameOver = true
        } else if guessedNumber < targetNumber {
            feedback = "Try higher."
        } else {
            feedback = "Try lower."
        }
    }
    
    func restartGame() {
        targetNumber = Int.random(in: 1...100)
        guess = ""
        isGameOver = false
        feedback = ""
        attempts = 0
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}




import SwiftUI


struct NumberWizardApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

struct ContentView: View {
    @State private var targetNumber = Int.random(in: 1...100)
    @State private var guess = ""
    @State private var isGameOver = false
    @State private var feedback = ""
    @State private var attempts = 0
    
    var body: some View {
        VStack {
            Text("Number Wizard")
                .font(.largeTitle)
                .padding()
            
            Text("Guess a number between 1 and 100.")
            
            TextField("Enter your guess", text: $guess)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .keyboardType(.numberPad)
                .padding()
            
            Button("Submit Guess") {
                checkGuess()
            }
            .padding()
            
            if isGameOver {
                Text(feedback)
                    .font(.headline)
                    .padding()
                
                Button("Play Again") {
                    restartGame()
                }
                .padding()
            }
        }
    }
    
    func checkGuess() {
        guard let guessedNumber = Int(guess) else {
            feedback = "Please enter a valid number."
            return
        }
        
        attempts += 1
        
        if guessedNumber == targetNumber {
            feedback = "Congratulations! You guessed it in \(attempts) attempts."
            isGameOver = true
        } else if guessedNumber < targetNumber {
            feedback = "Try higher."
        } else {
            feedback = "Try lower."
        }
    }
    
    func restartGame() {
        targetNumber = Int.random(in: 1...100)
        guess = ""
        isGameOver = false
        feedback = ""
        attempts = 0
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}



import SwiftUI


struct NumberWizardApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

struct ContentView: View {
    @State private var targetNumber = Int.random(in: 1...100)
    @State private var guess = ""
    @State private var isGameOver = false
    @State private var feedback = ""
    @State private var attempts = 0
    
    var body: some View {
        VStack {
            Text("Number Wizard")
                .font(.largeTitle)
                .padding()
            
            Text("I'm thinking of a number between 1 and 100.")
            
            TextField("Enter your guess", text: $guess)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .keyboardType(.numberPad)
                .padding()
            
            Button("Submit Guess") {
                checkGuess()
            }
            .padding()
            
            if isGameOver {
                Text(feedback)
                    .font(.headline)
                    .padding()
                
                Button("Play Again") {
                    restartGame()
                }
                .padding()
            }
        }
    }
    
    func checkGuess() {
        guard let guessedNumber = Int(guess) else {
            feedback = "Please enter a valid number."
            return
        }
        
        attempts += 1
        
        if guessedNumber == targetNumber {
            feedback = "Congratulations! You guessed it in \(attempts) attempts."
            isGameOver = true
        } else if guessedNumber < targetNumber {
            feedback = "Try higher."
        } else {
            feedback = "Try lower."
        }
    }
    
    func restartGame() {
        targetNumber = Int.random(in: 1...100)
        guess = ""
        isGameOver = false
        feedback = ""
        attempts = 0
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


import SwiftUI


struct NumberWizardApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

struct ContentView: View {
    @State private var targetNumber = Int.random(in: 1...100)
    @State private var guess = ""
    @State private var isGameOver = false
    @State private var feedback = ""
    @State private var attempts = 0
    
    var body: some View {
        VStack {
            Text("Number Wizard")
                .font(.largeTitle)
                .padding()
            
            Text("I'm thinking of a number between 1 and 100.")
            
            TextField("Enter your guess", text: $guess)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .keyboardType(.numberPad)
                .padding()
            
            Button("Submit Guess") {
                checkGuess()
            }
            .padding()
            
            if isGameOver {
                Text(feedback)
                    .font(.headline)
                    .padding()
                
                Button("Play Again") {
                    restartGame()
                }
                .padding()
            }
        }
    }
    
    func checkGuess() {
        guard let guessedNumber = Int(guess) else {
            feedback = "Please enter a valid number."
            return
        }
        
        attempts += 1
        
        if guessedNumber == targetNumber {
            feedback = "Congratulations! You guessed it in \(attempts) attempts."
            isGameOver = true
        } else if guessedNumber < targetNumber {
            feedback = "Try higher."
        } else {
            feedback = "Try lower."
        }
    }
    
    func restartGame() {
        targetNumber = Int.random(in: 1...100)
        guess = ""
        isGameOver = false
        feedback = ""
        attempts = 0
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundColor(.accentColor)
            Text("Hello, world!")
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
*/
