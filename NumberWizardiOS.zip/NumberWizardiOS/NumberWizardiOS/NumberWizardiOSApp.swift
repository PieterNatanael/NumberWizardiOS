//
//  NumberWizardiOSApp.swift
//  NumberWizardiOS
//
//  Created by Pieter Yoshua Natanael on 22/09/23.
//

import SwiftUI

@main
struct NumberWizardiOSApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
